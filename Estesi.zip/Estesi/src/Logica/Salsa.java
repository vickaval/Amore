package Logica;

public class Salsa extends Producto {
	
	 public Salsa(int idProducto, String nombre, double precio, int cantidad, int idDepo, int idProduccion, String tipo) {
	        super(idProducto, nombre, precio, cantidad, idDepo, idProduccion, tipo);
	    }

}
