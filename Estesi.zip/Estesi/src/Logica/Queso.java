package Logica;

public class Queso extends Producto {
	
	 public Queso(int idProducto, String nombre, double precio, int cantidad, int idDepo, int idProduccion, String tipo) {
	        super(idProducto, nombre, precio, cantidad, idDepo, idProduccion, tipo);
	    }

}
