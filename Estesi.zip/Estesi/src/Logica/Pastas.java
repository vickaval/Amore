package Logica;

public class Pastas extends Producto {
	
	 public Pastas(int idProducto, String nombre, double precio, int cantidad, int idDepo, int idProduccion, String tipo) {
	        super(idProducto, nombre, precio, cantidad, idDepo, idProduccion, tipo);
	    }


	
}